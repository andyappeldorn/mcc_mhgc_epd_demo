#include "gfx/legato/generated/le_gen_assets.h"

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   7
 *****************************************************************************/

/*****************************************************************************
 * string table data
 * 
 * this table contains the raw character data for each string
 * 
 * unsigned short - number of indices in the table
 * unsigned short - number of languages in the table
 * 
 * index array (size = number of indices * number of languages
 * 
 * for each index in the array:
 *   unsigned byte - the font ID for the index
 *   unsigned byte[3] - the offset of the string codepoint data in
 *                      the table
 * 
 * string data is found by jumping to the index offset from the start
 * of the table
 * 
 * string data entry:
 *     unsigned short - length of the string in bytes (encoding dependent)
 *     codepoint data - the string data
 ****************************************************************************/

const uint8_t stringTable_data[96] =
{
    0x07,0x00,0x01,0x00,0x00,0x20,0x00,0x00,0x00,0x26,0x00,0x00,0x00,0x2E,0x00,0x00,
    0x02,0x34,0x00,0x00,0x00,0x4A,0x00,0x00,0x00,0x50,0x00,0x00,0x01,0x5C,0x00,0x00,
    0x04,0x00,0x46,0x61,0x73,0x74,0x05,0x00,0x53,0x6D,0x61,0x72,0x74,0x00,0x04,0x00,
    0x45,0x61,0x73,0x79,0x14,0x00,0x53,0x63,0x61,0x6E,0x20,0x74,0x6F,0x20,0x67,0x65,
    0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x65,0x64,0x2E,0x04,0x00,0x42,0x61,0x63,0x6B,
    0x0A,0x00,0x51,0x75,0x69,0x63,0x6B,0x73,0x74,0x61,0x72,0x74,0x01,0x00,0x30,0x00,
};

/* font asset pointer list */
leFont* fontList[2] =
{
    (leFont*)&FontSmall,
    (leFont*)&FontBig,
};

const leStringTable stringTable =
{
    {
        LE_STREAM_LOCATION_ID_INTERNAL, // data location id
        (void*)stringTable_data, // data address pointer
        96, // data size
    },
    (void*)stringTable_data, // string table data
    fontList, // font lookup table
    LE_STRING_ENCODING_ASCII // encoding standard
};


// string list
leTableString string_strFast;
leTableString string_strSmart;
leTableString string_strEasy;
leTableString string_srtHelp;
leTableString string_strBack;
leTableString string_strQuickstart;
leTableString string_strCount;

void initializeStrings(void)
{
    leTableString_Constructor(&string_strFast, stringID_strFast);
    leTableString_Constructor(&string_strSmart, stringID_strSmart);
    leTableString_Constructor(&string_strEasy, stringID_strEasy);
    leTableString_Constructor(&string_srtHelp, stringID_srtHelp);
    leTableString_Constructor(&string_strBack, stringID_strBack);
    leTableString_Constructor(&string_strQuickstart, stringID_strQuickstart);
    leTableString_Constructor(&string_strCount, stringID_strCount);
}
